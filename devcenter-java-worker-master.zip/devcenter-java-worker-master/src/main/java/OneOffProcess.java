public class OneOffProcess
{
    public static void main(String[] args)
    {
        System.out.println("OneOffProcess executed.");
    }    
}
